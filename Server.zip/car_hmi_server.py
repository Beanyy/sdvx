import network_helpers
import uuid
import time
import threading

import car_hmi_pb2
import car_hmi_pb2_grpc

class CarHMIServicer(car_hmi_pb2_grpc.CarHMIServicer):
    def __init__(self, session_start = None, session_end = None):
        self.sessions = {}
        self.watchdog = network_helpers.PeriodicFunction(5, self.remove_inactive_sessions)
        self.watchdog.start()
        self.session_start = session_start
        self.session_end = session_end

    def cancel_watchdog(self):
        self.watchdog.cancel()

    def valid_id(self, id):
        return id in self.sessions

    def id_list(self):
        return list(self.sessions)

    def remove_all_sessions(self):
        for id in self.id_list():
            self.remove_session(id)

    def remove_session(self, id):
        if self.valid_id(id):
            self.sessions[id]['control'].stop()
            self.sessions[id]['frame'].stop()

            if self.session_end:
                self.session_end(id)
            del self.sessions[id]

    def remove_inactive_sessions(self):
        current_time = time.time()
        for id in self.id_list():
            if current_time - self.sessions[id]['last_ping'] > 5:
                print("Removing session", id)
                self.remove_session(id)
        return True

    def CreateSession(self, request, context):
        id = uuid.uuid4().hex
        session = {}
        session['name'] = request.name
        session['control'] = network_helpers.SendStreamServer()
        session['frame'] = network_helpers.RecvStreamServer()
        session['last_ping'] = time.time()

        self.sessions[id] = session
        if self.session_start:
            self.session_start(id, request)

        print("Created session", id)
        return car_hmi_pb2.SessionID(id=id)

    def Ping(self, request, context):
        if not self.valid_id(request.id):
            return car_hmi_pb2.Status(error_code=-1)
        self.sessions[request.id]['last_ping'] = time.time()
        return car_hmi_pb2.Status(error_code=0)

    def FrameStream(self, request_iterator, context):
        for request in request_iterator:
            if not self.valid_id(request.id):
                return car_hmi_pb2.Status(error_code=-1)
            self.sessions[request.id]['frame'].set(request)
        return car_hmi_pb2.Status(error_code=0)

    def ControlDataStream(self, request, context):
        if self.valid_id(request.id):
            yield from self.sessions[request.id]['control'].generate()

    def get_frame(self, id):
        if not self.valid_id(id):
            return None
        return self.sessions[id]['frame'].get()


    def send_control(self, id, data):
        if self.valid_id(id):
            control = car_hmi_pb2.Control(value=int(data))
            self.sessions[id]['control'].send_data(control)