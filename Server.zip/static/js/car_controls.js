+function ($) {
    $(document).ready(function() {

        var controlChange = function() {
            var new_throttle = throttle_slider.getValue();
            var new_steering = steering_slider.getValue();
            $('#throttle_txt').html('<i class="fa fa-space-shuttle"></i> Throttle: ' + new_throttle);
            $('#steering_txt').html('<i class="fa fa-undo"></i> Steering: ' + new_steering);
            $.post(window.location.pathname,
            {
              throttle: new_throttle,
              steering: new_steering
            },
            function(data,status){},
            'json');
        };


        var throttle_slider = $("#throttle").slider({
            id: 'throttle_slider',
            min: 0,
            max: 100,
            step: 1,
            value: 0
        }).on('slide', controlChange)
          .data('slider');
        var steering_slider = $("#steering").slider({
            id: 'steering_slider',
            min: -100,
            max: 100,
            step: 1,
            value: 0,
            rangeHighlights: [{ "start": -2, "end": 2, "class": "blue_range" }]
        }).on('slide', controlChange)
          .data('slider');
        controlChange();

        var buttons = [119, 97, 115, 100];
        $(document).keypress(function(e){
            if (e.which == 119) {
                throttle_slider.setValue(throttle_slider.getValue()+2, true);
            } else if(e.which == 115) {
                throttle_slider.setValue(throttle_slider.getValue()-2, true);
            } else if(e.which == 100) {
                steering_slider.setValue(steering_slider.getValue()+4, true);
            } else if(e.which == 97) {
                steering_slider.setValue(steering_slider.getValue()-4, true);
            }
        });

        $("#stopButton").click(function() {
            throttle_slider.setValue(0, true);
        });
        $("#centerButton").click(function() {
            steering_slider.setValue(0, true);
        });
    });
}(jQuery);