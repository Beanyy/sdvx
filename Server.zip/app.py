#!/usr/bin/env python
from importlib import import_module
import os
from flask import Flask, render_template, Response, request, json, jsonify, send_from_directory
from flask_bootstrap import Bootstrap

import grpc
from concurrent import futures
from car_hmi_server import CarHMIServicer
import car_hmi_pb2
import car_hmi_pb2_grpc

app = Flask(__name__)
bootstrap = Bootstrap(app)


@app.route('/')
def index():
    return render_template('base.html', connected_cars = connected_cars)

def gen_frame(id):
    """Video streaming generator function."""
    while True:
        frame = servicer.get_frame(id)
        if frame is None:
            return None
        if frame.encoding == 'jpg':
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame.data + b'\r\n')


@app.route('/video_feed/<id>')
def video_feed(id):
    """Video streaming route. Put this in the src attribute of an img tag."""
    type = request.args.get('type', 'main')
    if connected_cars.get(id, None):
        return Response(gen_frame(id), mimetype='multipart/x-mixed-replace; boundary=frame')
    return "Video feed not found"

@app.route('/car/<id>', methods=['GET', 'POST'])
def car_view(id):
    if request.method == 'POST':
        throttle = request.form['throttle']
        steering = request.form['steering']
        return Response(json.dumps(True), content_type='application/json')
    else:
        car = connected_cars.get(id, None);
        if car:
            return render_template('base.html', connected_cars = connected_cars, active_car=car, enable_control=True)
        return render_template('base.html', connected_cars = connected_cars)


def connection_callback(id, request):
    car = {}
    car['name'] = request.name
    connected_cars[id] = car

def disconnection_callback(id):
    if connected_cars.get(id, None):
        del connected_cars[id]

connected_cars = {}
servicer = CarHMIServicer(connection_callback, disconnection_callback)
server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
car_hmi_pb2_grpc.add_CarHMIServicer_to_server(servicer, server)
server.add_insecure_port('[::]:50051')
server.start()


if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', threaded=True)
    except KeyboardInterrupt:
        servicer.remove_all_sessions()
        servicer.cancel_watchdog()
        server.stop(0)
