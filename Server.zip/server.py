
import grpc
import cv2
import numpy as np
import time

from concurrent import futures
from car_hmi_server import CarHMIServicer
import car_hmi_pb2
import car_hmi_pb2_grpc

def serve():
    servicer = CarHMIServicer()
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    car_hmi_pb2_grpc.add_CarHMIServicer_to_server(servicer, server)
    server.add_insecure_port('[::]:50051')
    server.start()

    try:
        data = input("Enter a value")
        while True:
            frame = None
            if len(servicer.id_list()) > 0:
                frame = servicer.get_frame(servicer.id_list()[0])
            if not frame is None:
                if frame.encoding == 'jpg':
                    jpg = np.frombuffer(frame.data, np.uint8)
                    img = cv2.imdecode(jpg, cv2.IMREAD_UNCHANGED)
                    cv2.imshow('frame', img)
                    cv2.waitKey(1)
            else:
                print("No frame")
                time.sleep(2)
        #data = input("Enter a value")
        # servicer.send_control(servicer.id_list()[0], data)
        # time.sleep(8000)
    except KeyboardInterrupt:
        servicer.remove_all_sessions()
        servicer.cancel_watchdog()
        server.stop(0)

