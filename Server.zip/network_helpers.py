import time
import threading

class PeriodicFunction(object):
    """Periodically calls the passed function every specified interval."""
    def __init__(self, interval, f):
        """Interval is how often to call f. f returns True if the timer is to be restarted"""
        self.interval = interval
        self.f = f
        self.timer = None

    def callback(self):
        if self.f():
            self.start()

    def cancel(self):
        """Stop the timer"""
        self.timer.cancel()

    def start(self):
        """Restarts the timer"""
        self.timer = threading.Timer(self.interval, self.callback)
        self.timer.start()

class MultiEvent(object):
    """An Event-like class that signals all active clients when a new data is
    available.
    """
    def __init__(self):
        self.events = {}

    def wait(self):
        """Invoked from each client's thread to wait for the next frame."""
        ident = threading.get_ident()
        if ident not in self.events:
            # this is a new client
            # add an entry for it in the self.events dict
            # each entry has two elements, a threading.Event() and a timestamp
            self.events[ident] = [threading.Event(), time.time()]
        return self.events[ident][0].wait()

    def set(self):
        """Invoked by the producer when new data is available."""
        now = time.time()
        remove = None
        for ident, event in self.events.items():
            if not event[0].isSet():
                # if this client's event is not set, then set it
                # also update the last set timestamp to now
                event[0].set()
                event[1] = now
            else:
                # if the client's event is already set, it means the client
                # did not process a previous frame
                # if the event stays set for more than 5 seconds, then assume
                # the client is gone and remove it
                if now - event[1] > 5:
                    remove = ident
        if remove:
            del self.events[remove]

    def clear(self):
        """Invoked from each client's thread after data was processed."""
        self.events[threading.get_ident()][0].clear()

class SendStreamServer(object):
    def __init__(self):
        self.data_available = threading.Event()
        self.data = None
        self.running = True

    def send_data(self, data):
        self.data = data
        self.data_available.set()

    def stop(self):
        self.running = False
        self.data_available.set()

    def generate(self):
        while True:
            self.data_available.wait()
            self.data_available.clear()
            if not self.running:
                break
            yield self.data

class RecvStreamServer(object):
    def __init__(self):
        self.data_available = MultiEvent()
        self.data = None
        self.running = True

    def set(self, data):
        self.data = data
        self.data_available.set()

    def stop(self):
        self.running = False
        self.data_available.set()
        
    def get(self):
        self.data_available.wait()
        self.data_available.clear()
        if not self.running:
            return None
        return self.data

class SendStream(object):
    def __init__(self, stream, callback):
        self.data_available = threading.Event()
        self.data = None
        self.future = stream.future(self.generate())
        self.callback = callback

    def send_data(self, data):
        if (self.future and self.future.done()):
            self.future = None
            self.callback()
            return

        self.data = data
        self.data_available.set()

    def generate(self):
        while True:
            self.data_available.wait()
            self.data_available.clear()
            yield self.data