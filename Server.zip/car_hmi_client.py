import grpc
import network_helpers
import time
import threading

import car_hmi_pb2
import car_hmi_pb2_grpc

class CarHMIClient(object):
    def __init__(self, name, ip='127.0.0.1', port=50051):
        self.channel = grpc.insecure_channel(ip+':'+str(port))
        self.interface = car_hmi_pb2_grpc.CarHMIStub(self.channel)
        self.name = car_hmi_pb2.DeviceName(name=name)
        self.id = None

        self.session_event = threading.Event()
        self.thread = threading.Thread(target=self.session_connect, daemon=True)
        self.thread.start()
        
        self.frame_stream = None
        self.control_thread = None

    def session_connect(self):
        while 1:
            try:
                self.id = self.interface.CreateSession(self.name).id
                self.frame_stream = network_helpers.SendStream(self.interface.FrameStream, self.session_reconnect)
                self.control_thread = threading.Thread(target=self.get_control_data, daemon=True)
                self.control_thread.start()
                self.pinger = network_helpers.PeriodicFunction(3, self.ping)
                self.pinger.start()
                print("Connected!")
                self.session_event.wait()
                self.session_event.clear()
            except grpc._channel._Rendezvous as err:
                print("Connection to server failed, Retrying in 3...")
                time.sleep(3)

    def session_reconnect(self):
        self.id = None
        self.frame_stream = None
        self.control_thread.join()
        self.control_thread = None
        self.pinger.cancel()
        self.session_event.set()

    def ping(self):
        try:
            id = car_hmi_pb2.SessionID(id=self.id)
            ret = self.interface.Ping(id)
            return True
        except grpc._channel._Rendezvous as err:
            self.session_reconnect()
            return False

    def get_control_data(self):
        id = car_hmi_pb2.SessionID(id=self.id)
        try:
            for control in self.interface.ControlDataStream(id):
                print(control.value)
        except grpc._channel._Rendezvous as err:
            pass

    def send_jpg(self, jpg):
        if self.frame_stream:
            frame = car_hmi_pb2.Frame(id=self.id, encoding='jpg', data=jpg)
            self.frame_stream.send_data(frame)