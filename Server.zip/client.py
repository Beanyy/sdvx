from car_hmi_client import CarHMIClient
import cv2

import car_hmi_pb2
import car_hmi_pb2_grpc


def run():
    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        raise RuntimeError('Could not start camera.')

    display = False
    carhmi = CarHMIClient('EddyCar')
    while True:
        retval, img = camera.read()
        # encode as a jpeg image and return it
        if retval and display:
            cv2.imshow('frame',img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        jpg = cv2.imencode('.jpg', img)[1].tobytes()
        carhmi.send_jpg(jpg)


if __name__ == '__main__':
    run()
